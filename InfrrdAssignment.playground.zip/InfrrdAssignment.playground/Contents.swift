
extension Array where Element: Comparable {
  var isInDescendingOrder: Bool {
    for i in 1...self.count-1 {
      if self[i-1] < self[i] { return false }
    }
    return true
  }
}

var shipsLoot = [3,6,2,7,5]
var indexedArray: [Int] = []

var numberofDays = calculateDays()

print("Ships will stop getting destroyed after - \(numberofDays) days")

func calculateDays() -> Int {
        
    if shipsLoot.count <= 1 {
        return 0
    }
    
    while !shipsLoot.isInDescendingOrder {
            
        for i in 1..<shipsLoot.count{
                    
            if shipsLoot[i] > shipsLoot[i-1] {
                indexedArray.append(i)
            }
        }
            
        shipsLoot = shipsLoot
                    .enumerated()
                    .filter { !indexedArray.contains($0.offset) }
                    .map { $0.element }

        indexedArray.removeAll()
        numberofDays += 1
       
    }
        
    return numberofDays

}



    
   
